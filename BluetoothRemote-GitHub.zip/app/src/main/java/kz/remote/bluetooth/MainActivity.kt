package kz.remote.bluetooth

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val adapter by lazy { (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter }
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var connected = false
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var mouseButtons = 0
    private var mods = 0
    private val executor = Executors.newSingleThreadExecutor()

    // Report ID 1 = mouse: buttons, X, Y, wheel. Report ID 2 = keyboard: modifier, reserved, 6 key codes.
    private val descriptor = byteArrayOf(
        0x05,0x01,0x09,0x02,0xA1.toByte(),0x01,0x85.toByte(),0x01,0x09,0x01,0xA1.toByte(),0x00,
        0x05,0x09,0x19,0x01,0x29,0x03,0x15,0x00,0x25,0x01,0x95.toByte(),0x03,0x75,0x01,0x81.toByte(),0x02,
        0x95.toByte(),0x01,0x75,0x05,0x81.toByte(),0x03,0x05,0x01,0x09,0x30,0x09,0x31,0x09,0x38,
        0x15,0x81.toByte(),0x25,0x7F,0x75,0x08,0x95.toByte(),0x03,0x81.toByte(),0x06,0xC0.toByte(),0xC0.toByte(),
        0x05,0x01,0x09,0x06,0xA1.toByte(),0x01,0x85.toByte(),0x02,0x05,0x07,0x19,0xE0.toByte(),0x29,0xE7.toByte(),
        0x15,0x00,0x25,0x01,0x75,0x01,0x95.toByte(),0x08,0x81.toByte(),0x02,
        0x95.toByte(),0x01,0x75,0x08,0x81.toByte(),0x03,
        0x95.toByte(),0x06,0x75,0x08,0x15,0x00,0x25,0x65,0x05,0x07,0x19,0x00,0x29,0x65,0x81.toByte(),0x00,0xC0.toByte()
    )

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            runOnUiThread { setStatus(if (registered) "HID зарегистрирован. Выберите сопряжённый ПК." else "HID недоступен или регистрация сброшена") }
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            connected = state == BluetoothProfile.STATE_CONNECTED
            if (connected) host = device
            runOnUiThread { setStatus(if (connected) "Подключено: ${deviceName(device)}" else "Отключено") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 20)
        }
        showMouse()
        initializeHid()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) initializeHid()
        else if (requestCode == 20) setStatus("Разрешите доступ к Bluetooth в настройках приложения")
    }

    private fun hasPermission(): Boolean = Build.VERSION.SDK_INT < 31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    private fun deviceName(device: BluetoothDevice): String = if (hasPermission()) device.name ?: device.address else "ПК"
    private fun initializeHid() {
        if (!hasPermission()) return
        if (adapter == null || !adapter.isEnabled) { setStatus("Включите Bluetooth на телефоне"); return }
        adapter.getProfileProxy(this, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                hid = proxy as BluetoothHidDevice
                val sdp = BluetoothHidDeviceAppSdpSettings("Bluetooth Remote", "Android Mouse and Keyboard", "Android", BluetoothHidDevice.SUBCLASS1_COMBO, descriptor)
                val ok = hid?.registerApp(sdp, null as BluetoothHidDeviceAppQosSettings?, null as BluetoothHidDeviceAppQosSettings?, executor, callback) ?: false
                runOnUiThread { if (!ok) setStatus("Не удалось зарегистрировать HID. Возможно, прошивка не поддерживает режим.") }
            }
            override fun onServiceDisconnected(profile: Int) { hid = null; connected = false; runOnUiThread { setStatus("Bluetooth HID отключён") } }
        }, BluetoothProfile.HID_DEVICE)
    }

    private fun base(title: String): LinearLayout {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18,24,18,12) }
        val header = TextView(this).apply { text = title; textSize = 24f; gravity = Gravity.CENTER }
        root.addView(header)
        status = TextView(this).apply { textSize = 14f; gravity = Gravity.CENTER; text = if (connected) "Подключено" else "Не подключено" }
        root.addView(status)
        val connect = button("Bluetooth: подключить ПК") { showDevices() }
        root.addView(connect)
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabs.addView(button("МЫШЬ") { showMouse() }, LinearLayout.LayoutParams(0, 56, 1f))
        tabs.addView(button("КЛАВИАТУРА") { showKeyboard() }, LinearLayout.LayoutParams(0, 56, 1f))
        root.addView(tabs)
        setContentView(root)
        return root
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply { text = label; setOnClickListener { action() } }
    private fun setStatus(s: String) { if (::status.isInitialized) status.text = s }

    private fun showDevices() {
        if (!hasPermission()) { setStatus("Нет разрешения Bluetooth"); return }
        val devices = adapter?.bondedDevices?.toList().orEmpty()
        if (devices.isEmpty()) { setStatus("Сначала выполните сопряжение в настройках Bluetooth Android и Windows"); return }
        val names = devices.map { "${deviceName(it)} (${it.address})" }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Сопряжённые устройства")
            .setItems(names) { _, i ->
                host = devices[i]
                val ok = hid?.connect(devices[i]) ?: false
                setStatus(if (ok) "Запрос подключения отправлен: ${deviceName(devices[i])}" else "Не удалось подключиться. Проверьте HID и сопряжение")
            }.setNegativeButton("Отмена", null).show()
    }

    private fun sendMouse(dx: Int = 0, dy: Int = 0, wheel: Int = 0) {
        if (!connected) return
        val d = host ?: return
        hid?.sendReport(d, 1, byteArrayOf(mouseButtons.toByte(), dx.coerceIn(-127,127).toByte(), dy.coerceIn(-127,127).toByte(), wheel.coerceIn(-127,127).toByte()))
    }
    private fun mouseClick(mask: Int) { mouseButtons = mask; sendMouse(); mouseButtons = 0; sendMouse() }
    private fun showMouse() {
        val view = base("Bluetooth Mouse")
        val pad = TextView(this).apply {
            text = "Водите пальцем по панели\n\nОдно касание — левый клик\nДва пальца — прокрутка"
            textSize = 18f; gravity = Gravity.CENTER; setBackgroundColor(0xFFE4EBF4.toInt())
        }
        var px = 0f; var py = 0f; var moved = false
        pad.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { px = e.x; py = e.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - px; val dy = e.y - py
                    if (kotlin.math.abs(dx) > 2 || kotlin.math.abs(dy) > 2) moved = true
                    if (e.pointerCount >= 2) sendMouse(wheel = (-dy / 15).roundToInt())
                    else sendMouse((dx * 1.3f).roundToInt(), (dy * 1.3f).roundToInt())
                    px = e.x; py = e.y; true
                }
                MotionEvent.ACTION_UP -> { if (!moved) mouseClick(1); true }
                else -> true
            }
        }
        view.addView(pad, LinearLayout.LayoutParams(-1, 0, 1f))
        val clicks = LinearLayout(this)
        clicks.addView(button("ЛКМ") { mouseClick(1) }, LinearLayout.LayoutParams(0, 60, 1f))
        clicks.addView(button("ПКМ") { mouseClick(2) }, LinearLayout.LayoutParams(0, 60, 1f))
        view.addView(clicks)
        val extra = LinearLayout(this)
        extra.addView(button("Двойной клик") { mouseClick(1); mouseClick(1) }, LinearLayout.LayoutParams(0, 55, 1f))
        extra.addView(button("Прокрутка ↑") { sendMouse(wheel = 3) }, LinearLayout.LayoutParams(0, 55, 1f))
        extra.addView(button("Прокрутка ↓") { sendMouse(wheel = -3) }, LinearLayout.LayoutParams(0, 55, 1f))
        view.addView(extra)
    }

    private fun sendKey(code: Int, modifier: Int = mods) {
        if (!connected) return
        val d = host ?: return
        val down = byteArrayOf(modifier.toByte(),0,code.toByte(),0,0,0,0,0)
        val up = ByteArray(8)
        hid?.sendReport(d,2,down)
        // Delayed release prevents rapid successive key events from being merged by some hosts.
        android.os.Handler(mainLooper).postDelayed({ hid?.sendReport(d,2,up) }, 35)
    }
    private fun keyFor(c: Char): Pair<Int,Int>? {
        val lower = c.lowercaseChar()
        if (lower in 'a'..'z') return Pair(4 + lower.code - 'a'.code, if (c.isUpperCase()) 2 else 0)
        if (c in '1'..'9') return Pair(30 + c.code - '1'.code,0)
        if (c == '0') return Pair(39,0)
        return when(c) {
            ' ' -> Pair(44,0); '\n' -> Pair(40,0); '.' -> Pair(55,0); ',' -> Pair(54,0)
            '-' -> Pair(45,0); '=' -> Pair(46,0); '/' -> Pair(56,0); ';' -> Pair(51,0)
            else -> null
        }
    }
    private fun showKeyboard() {
        val view = base("Bluetooth Keyboard")
        val input = EditText(this).apply { hint = "Введите латинский текст и нажмите Отправить"; minLines = 2 }
        view.addView(input)
        view.addView(button("Отправить текст") {
            val typed = input.text.toString()
            val unsupported = typed.filter { keyFor(it) == null }.toSet()
            if (unsupported.isNotEmpty()) { setStatus("Неподдерживаемые символы: ${unsupported.joinToString("")}"); return@button }
            // Pace events to keep key-down and key-up ordering stable.
            typed.forEachIndexed { index, c ->
                val pair = keyFor(c) ?: return@forEachIndexed
                android.os.Handler(mainLooper).postDelayed({ sendKey(pair.first, pair.second) }, index * 90L)
            }
        })
        val modifiers = LinearLayout(this)
        listOf("Ctrl" to 1, "Shift" to 2, "Alt" to 4, "Win" to 8).forEach { (name,bit) ->
            val b = button(name) { mods = mods xor bit; setStatus("Модификаторы: $mods (повторное нажатие выключает)") }
            modifiers.addView(b, LinearLayout.LayoutParams(0, 50, 1f))
        }
        view.addView(modifiers)
        val rows = listOf(
            listOf("Esc" to 41,"Tab" to 43,"Backspace" to 42,"Enter" to 40),
            listOf("↑" to 82,"↓" to 81,"←" to 80,"→" to 79),
            listOf("Home" to 74,"End" to 77,"Del" to 76,"Space" to 44),
            listOf("F1" to 58,"F2" to 59,"F3" to 60,"F4" to 61),
            listOf("F5" to 62,"F6" to 63,"F7" to 64,"F8" to 65),
            listOf("F9" to 66,"F10" to 67,"F11" to 68,"F12" to 69)
        )
        rows.forEach { row ->
            val line = LinearLayout(this)
            row.forEach { (name,code) -> line.addView(button(name) { sendKey(code) }, LinearLayout.LayoutParams(0, 52, 1f)) }
            view.addView(line)
        }
        view.addView(button("Сбросить Ctrl / Shift / Alt / Win") { mods = 0; setStatus("Модификаторы выключены") })
    }
    override fun onDestroy() {
        if (hasPermission()) { host?.let { if (connected) hid?.disconnect(it) }; hid?.unregisterApp(); hid?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) } }
        executor.shutdown()
        super.onDestroy()
    }
}
